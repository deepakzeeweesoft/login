var mysql = require('mysql');
var express = require('express');
var app = express();
var bodyParser = require('body-parser')

app.use(bodyParser.json())


const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'samo123',
    database: 'Othentication',
    // multipleStatements:true
});
// connection.connect();
connection.connect(function (err) {
    if (!err)
        console.log("Database is Connected!");
    else
        console.log("Database connection is faild")
});



app.listen(3000, () => {
    console.log('Express api is running on 3000');
})



//get all usser from the database 
app.get('/getRegisterUsserList', (req, res, next) => {

    console.log("get api is work")
    connection.query("SELECT * FROM register_usser", (err, data) => {
        if (!err) {
            console.log("data: ", data);
            //   result(null, err);
           // res.send(data)
            //   return;
            res.status(200).json(data)
                  }
        else {
            console.log(err)
            // res.send(data)
             }
        console.log(data, 'data')
    })
})



app.post('/AddUsser', (req, res) => {
    console.log("post api is work")
   
    
    sql = "INSERT INTO register_usser SET ? ";
    connection.query(sql, [req.body] , (err,data) => {
        if (!err) {
            console.log("Updated Successfull !!!! ", data);

            res.send(data)
        }
        else
            console.log(err);
    })
})



// {
//     "First_Name": "Deepak",
//     "Last_Name": "Dubey",
//     "Email": "dubey@gmail.com",
//     "Password": "12345678"
// }