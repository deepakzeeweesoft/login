import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { createSecureServer } from 'http2';

@Injectable({
  providedIn: 'root'
})
export class OthenticationService {

  constructor(private httpClient:HttpClient) { }

}



creatusser(item:any)
                 {
                    console.log("create product");
                    console.log("item is",item)
                    // return this.httpClient.post<any>("http://localhost:3000/Addproduct",item);
                    return this.httpClient.post<any>("http://localhost:3000/Addproduct",item);
                    console.log('create product is work');
                 }


