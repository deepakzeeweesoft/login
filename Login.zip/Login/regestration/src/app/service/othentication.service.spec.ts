import { TestBed } from '@angular/core/testing';

import { OthenticationService } from './othentication.service';

describe('OthenticationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OthenticationService = TestBed.get(OthenticationService);
    expect(service).toBeTruthy();
  });
});
